"use server"

export async function convertTextToSpeech(
  text: string,
  voiceId: string,
  options: {
    speed: number
    pitch: number
    emotion: string
  },
) {
  try {
    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}/stream`, {
      method: "POST",
      headers: {
        "xi-api-key": "sk_c0be9b332b4b688eda5abe9f7a1a100e15bbf525243b0ee6",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        text: text,
        model_id: "eleven_multilingual_v2",
        voice_settings: {
          stability: options.emotion === "calm" ? 0.3 : options.emotion === "excited" ? 0.8 : 0.5,
          similarity_boost: 0.7,
          style: options.emotion === "dramatic" ? 0.8 : 0.3,
          use_speaker_boost: true,
        },
      }),
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))

      // Handle specific ElevenLabs errors
      if (response.status === 401) {
        if (errorData.detail?.status === "detected_unusual_activity") {
          return {
            success: false,
            error: "UNUSUAL_ACTIVITY",
            message:
              "ElevenLabs detected unusual activity and disabled free tier access. This commonly happens with free accounts. Please upgrade to a paid plan to continue using voice synthesis.",
            fallback: true,
          }
        }
        return {
          success: false,
          error: "INVALID_API_KEY",
          message: "Invalid API key. Please check your ElevenLabs API key configuration.",
          fallback: true,
        }
      }

      if (response.status === 429) {
        return {
          success: false,
          error: "RATE_LIMIT",
          message: "Rate limit exceeded. Please wait a moment and try again.",
          fallback: true,
        }
      }

      if (response.status === 422) {
        return {
          success: false,
          error: "QUOTA_EXCEEDED",
          message: "Monthly quota exceeded. Please upgrade your ElevenLabs plan.",
          fallback: true,
        }
      }

      return {
        success: false,
        error: `API_ERROR_${response.status}`,
        message: "ElevenLabs API error occurred. Please try again later.",
        fallback: true,
      }
    }

    const audioBuffer = await response.arrayBuffer()
    const audioBlob = new Blob([audioBuffer], { type: "audio/mpeg" })
    const audioUrl = URL.createObjectURL(audioBlob)

    return {
      success: true,
      audioUrl: audioUrl,
      contentType: "audio/mpeg",
      message: "Voice generated successfully!",
    }
  } catch (error: any) {
    console.error("ElevenLabs API error:", error)

    // Handle network and other errors
    return {
      success: false,
      error: error.message || "NETWORK_ERROR",
      message: "Unable to connect to ElevenLabs API. Please check your internet connection and try again.",
      fallback: true,
    }
  }
}

// Simple fallback function that returns demo data
export async function generateFallbackDemo(text: string, voiceId: string, options: any) {
  // Simulate processing time
  await new Promise((resolve) => setTimeout(resolve, 1500))

  // Get voice info for demo
  const voiceInfo = getVoiceInfo(voiceId)

  return {
    success: true,
    demo: true,
    message: `Demo mode: Would generate "${text.slice(0, 50)}${text.length > 50 ? "..." : ""}" using ${voiceInfo.name} voice with ${options.emotion} emotion at ${options.speed}x speed.`,
    voiceInfo: voiceInfo,
    textLength: text.length,
    estimatedDuration: Math.ceil(text.length / 10), // Rough estimate: 10 chars per second
  }
}

function getVoiceInfo(voiceId: string) {
  const voiceMap: Record<string, { name: string; gender: string; accent: string }> = {
    "21m00Tcm4TlvDq8ikWAM": { name: "Rachel", gender: "Female", accent: "American" },
    AZnzlk1XvdvUeBnXmlld: { name: "Domi", gender: "Female", accent: "American" },
    EXAVITQu4vr4xnSDxMaL: { name: "Bella", gender: "Female", accent: "American" },
    ErXwobaYiN019PkySvjV: { name: "Antoni", gender: "Male", accent: "American" },
    MF3mGyEYCl7XYWbV9V6O: { name: "Elli", gender: "Female", accent: "American" },
    TxGEqnHWrfWFTfGW9XjX: { name: "Josh", gender: "Male", accent: "American" },
  }

  return voiceMap[voiceId] || { name: "Unknown Voice", gender: "Unknown", accent: "Unknown" }
}
