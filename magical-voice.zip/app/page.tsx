"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import {
  Mic,
  Play,
  Download,
  Trash2,
  Moon,
  Sun,
  Volume2,
  Settings,
  Sparkles,
  Users,
  BookOpen,
  Video,
  Presentation,
  Heart,
  MessageCircle,
  Phone,
  Mail,
  Pause,
  Loader2,
  AlertTriangle,
  Info,
  CheckCircle,
  HelpCircle,
  Upload,
} from "lucide-react"
import { convertTextToSpeech, generateFallbackDemo } from "./actions"

const ParticleBackground = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    resizeCanvas()

    const particles: Array<{
      x: number
      y: number
      vx: number
      vy: number
      size: number
      opacity: number
      color: string
    }> = []

    const colors = ["#9b5de5", "#2c0e4f", "#f8f8f8"]

    for (let i = 0; i < 80; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.8,
        vy: (Math.random() - 0.5) * 0.8,
        size: Math.random() * 4 + 1,
        opacity: Math.random() * 0.6 + 0.2,
        color: colors[Math.floor(Math.random() * colors.length)],
      })
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      particles.forEach((particle, index) => {
        particle.x += particle.vx
        particle.y += particle.vy

        if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1
        if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1

        // Create glow effect
        ctx.shadowBlur = 20
        ctx.shadowColor = particle.color
        ctx.beginPath()
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
        ctx.fillStyle = particle.color
        ctx.globalAlpha = particle.opacity
        ctx.fill()
        ctx.shadowBlur = 0
        ctx.globalAlpha = 1

        // Connect nearby particles
        particles.slice(index + 1).forEach((otherParticle) => {
          const dx = particle.x - otherParticle.x
          const dy = particle.y - otherParticle.y
          const distance = Math.sqrt(dx * dx + dy * dy)

          if (distance < 100) {
            ctx.beginPath()
            ctx.moveTo(particle.x, particle.y)
            ctx.lineTo(otherParticle.x, otherParticle.y)
            ctx.strokeStyle = `rgba(155, 93, 229, ${0.1 * (1 - distance / 100)})`
            ctx.lineWidth = 1
            ctx.stroke()
          }
        })
      })

      requestAnimationFrame(animate)
    }

    animate()

    window.addEventListener("resize", resizeCanvas)
    return () => window.removeEventListener("resize", resizeCanvas)
  }, [])

  return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-0" />
}

const FloatingMic = () => {
  return (
    <div className="relative flex items-center justify-center">
      <div className="absolute inset-0 animate-ping">
        <div className="w-20 h-20 rounded-full bg-gradient-to-r from-violet-400 to-purple-600 opacity-20" />
      </div>
      <div className="relative z-10 p-4 rounded-full bg-gradient-to-r from-violet-500/20 to-purple-600/20 backdrop-blur-sm border border-violet-300/30">
        <Mic className="w-12 h-12 text-violet-300 animate-pulse" />
        <div className="absolute -inset-1 bg-gradient-to-r from-violet-400 to-purple-600 rounded-full opacity-30 animate-pulse" />
      </div>
      <div className="absolute inset-0 animate-spin-slow">
        <Sparkles className="w-6 h-6 text-yellow-400 absolute -top-2 -right-2" />
        <Sparkles className="w-4 h-4 text-pink-400 absolute -bottom-1 -left-1" />
        <Sparkles className="w-5 h-5 text-blue-400 absolute top-1 -left-3" />
      </div>
    </div>
  )
}

const WaveformAnimation = ({ isPlaying }: { isPlaying: boolean }) => {
  return (
    <div className="flex items-center justify-center space-x-1 h-12 p-4 rounded-xl bg-gradient-to-r from-violet-500/10 to-purple-600/10 backdrop-blur-sm border border-violet-300/20">
      {[...Array(20)].map((_, i) => (
        <div
          key={i}
          className={`w-1 bg-gradient-to-t from-violet-400 to-purple-600 rounded-full transition-all duration-150 ${
            isPlaying ? "animate-pulse" : ""
          }`}
          style={{
            height: isPlaying ? `${Math.random() * 30 + 10}px` : "6px",
            animationDelay: `${i * 0.05}s`,
            animationDuration: `${0.5 + Math.random() * 0.5}s`,
          }}
        />
      ))}
    </div>
  )
}

// Urdu Help Modal Component
const UrduHelpModal = ({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) => {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <Card className="max-w-2xl w-full backdrop-blur-xl bg-white/10 border border-white/20 rounded-3xl">
        <CardContent className="p-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-bold bg-gradient-to-r from-violet-400 to-purple-600 bg-clip-text text-transparent">
              🇵🇰 How to Enable Urdu Voice
            </h3>
            <Button variant="ghost" size="sm" onClick={onClose} className="text-gray-400 hover:text-white">
              ×
            </Button>
          </div>

          <div className="space-y-6 text-sm">
            <div className="p-4 rounded-xl bg-orange-500/10 border border-orange-400/30">
              <div className="flex items-center space-x-2 mb-2">
                <AlertTriangle className="w-5 h-5 text-orange-400" />
                <span className="font-semibold text-orange-400">Why Urdu doesn't work?</span>
              </div>
              <p className="text-gray-300">
                Most browsers and operating systems don't have Urdu voices installed by default. You need to install
                them manually.
              </p>
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold text-lg">📱 How to Install Urdu Voices:</h4>

              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-400/30">
                  <h5 className="font-semibold text-blue-400 mb-2">🪟 Windows:</h5>
                  <ol className="list-decimal list-inside space-y-1 text-gray-300">
                    <li>Go to Settings → Time & Language → Speech</li>
                    <li>Click "Add voices" and search for "Urdu"</li>
                    <li>Install "Microsoft Urdu (Pakistan)" voice</li>
                    <li>Restart your browser</li>
                  </ol>
                </div>

                <div className="p-4 rounded-xl bg-green-500/10 border border-green-400/30">
                  <h5 className="font-semibold text-green-400 mb-2">🍎 macOS:</h5>
                  <ol className="list-decimal list-inside space-y-1 text-gray-300">
                    <li>Go to System Preferences → Accessibility → Speech</li>
                    <li>Click "System Voice" dropdown</li>
                    <li>Select "Customize..." and download Urdu voices</li>
                    <li>Restart your browser</li>
                  </ol>
                </div>

                <div className="p-4 rounded-xl bg-purple-500/10 border border-purple-400/30">
                  <h5 className="font-semibold text-purple-400 mb-2">📱 Android:</h5>
                  <ol className="list-decimal list-inside space-y-1 text-gray-300">
                    <li>Go to Settings → Language & Input → Text-to-speech</li>
                    <li>Select Google Text-to-speech Engine</li>
                    <li>Install Urdu language pack</li>
                    <li>Use Chrome browser for best results</li>
                  </ol>
                </div>

                <div className="p-4 rounded-xl bg-gray-500/10 border border-gray-400/30">
                  <h5 className="font-semibold text-gray-400 mb-2">📱 iOS:</h5>
                  <ol className="list-decimal list-inside space-y-1 text-gray-300">
                    <li>Go to Settings → Accessibility → Spoken Content</li>
                    <li>Tap "Voices" → Add New Language</li>
                    <li>Download Urdu voice pack</li>
                    <li>Use Safari browser</li>
                  </ol>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-400/30">
              <div className="flex items-center space-x-2 mb-2">
                <Info className="w-5 h-5 text-blue-400" />
                <span className="font-semibold text-blue-400">💡 Pro Tip:</span>
              </div>
              <p className="text-gray-300">
                <strong>Hindi voices work perfectly for Urdu text!</strong> If you can't find Urdu voices, install Hindi
                language pack instead. Hindi and Urdu share the same pronunciation system, so Hindi voices will speak
                your Urdu text clearly.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-purple-500/10 border border-purple-400/30">
              <h5 className="font-semibold text-purple-400 mb-2">🇮🇳 Install Hindi Voices (Works for Urdu):</h5>
              <ol className="list-decimal list-inside space-y-1 text-gray-300">
                <li>Go to Windows Settings → Time & Language → Speech</li>
                <li>Click "Add voices" and search for "Hindi"</li>
                <li>Install "Microsoft Hindi (India)" voice</li>
                <li>Select Hindi voice in the app - it will speak Urdu perfectly!</li>
              </ol>
            </div>

            <div className="p-4 rounded-xl bg-green-500/10 border border-green-400/30">
              <div className="flex items-center space-x-2 mb-2">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span className="font-semibold text-green-400">Alternative Solution:</span>
              </div>
              <p className="text-gray-300">
                For the best Urdu voice experience, upgrade to ElevenLabs paid plan which includes high-quality
                multilingual AI voices.
              </p>
            </div>
          </div>

          <div className="flex justify-center mt-6">
            <Button
              onClick={onClose}
              className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 rounded-xl px-8"
            >
              Got it!
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default function MagicalVoice() {
  const [darkMode, setDarkMode] = useState(false)
  const [selectedLanguage, setSelectedLanguage] = useState("english")
  const [selectedVoice, setSelectedVoice] = useState("")
  const [text, setText] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [speed, setSpeed] = useState([1])
  const [pitch, setPitch] = useState([1])
  const [emotion, setEmotion] = useState("natural")
  const [isPlaying, setIsPlaying] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [recentConversions, setRecentConversions] = useState<string[]>([])
  const [currentAudio, setCurrentAudio] = useState<HTMLAudioElement | null>(null)
  const [autoDetect, setAutoDetect] = useState(false)
  const [apiError, setApiError] = useState<string | null>(null)
  const [fallbackMode, setFallbackMode] = useState(false)
  const [demoResult, setDemoResult] = useState<any>(null)
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([])
  const [currentUtterance, setCurrentUtterance] = useState<SpeechSynthesisUtterance | null>(null)
  const [showUrduHelp, setShowUrduHelp] = useState(false)
  const [hasUrduVoices, setHasUrduVoices] = useState(false)

  const audioRef = useRef<HTMLAudioElement>(null)

  // Web Speech API voices - these will be populated from browser
  const [webSpeechVoices, setWebSpeechVoices] = useState<{
    english: Array<{ id: string; name: string; accent: string; gender: string; voice: SpeechSynthesisVoice }>
    urdu: Array<{ id: string; name: string; accent: string; gender: string; voice: SpeechSynthesisVoice }>
  }>({
    english: [],
    urdu: [],
  })

  // Fallback voice definitions for UI
  const voices = {
    english: [
      { id: "21m00Tcm4TlvDq8ikWAM", name: "Rachel - Professional", accent: "American", gender: "Female" },
      { id: "AZnzlk1XvdvUeBnXmlld", name: "Domi - Narrative", accent: "American", gender: "Female" },
      { id: "EXAVITQu4vr4xnSDxMaL", name: "Bella - Conversational", accent: "American", gender: "Female" },
      { id: "ErXwobaYiN019PkySvjV", name: "Antoni - Warm", accent: "American", gender: "Male" },
      { id: "MF3mGyEYCl7XYWbV9V6O", name: "Elli - Energetic", accent: "American", gender: "Female" },
      { id: "TxGEqnHWrfWFTfGW9XjX", name: "Josh - Deep", accent: "American", gender: "Male" },
    ],
    urdu: [
      { id: "21m00Tcm4TlvDq8ikWAM", name: "Ayesha - Classical", accent: "Pakistani", gender: "Female" },
      { id: "ErXwobaYiN019PkySvjV", name: "Ali - Deep", accent: "Pakistani", gender: "Male" },
      { id: "EXAVITQu4vr4xnSDxMaL", name: "Fatima - Melodic", accent: "Pakistani", gender: "Female" },
      { id: "TxGEqnHWrfWFTfGW9XjX", name: "Hassan - Narrative", accent: "Pakistani", gender: "Male" },
    ],
  }

  const sampleVoices = [
    {
      id: "rachel-sample",
      name: "Rachel",
      language: "English",
      text: "Welcome to the future of voice synthesis with Magical Voice",
      flag: "🇬🇧",
      voiceId: "21m00Tcm4TlvDq8ikWAM",
    },
    {
      id: "antoni-sample",
      name: "Antoni",
      language: "English",
      text: "Transform your words into magical, lifelike speech",
      flag: "🇺🇸",
      voiceId: "ErXwobaYiN019PkySvjV",
    },
    {
      id: "ayesha-sample",
      name: "Ayesha",
      language: "Urdu",
      text: "آپ کے الفاظ کو جادوئی آواز میں تبدیل کریں",
      flag: "🇵🇰",
      voiceId: "21m00Tcm4TlvDq8ikWAM",
    },
    {
      id: "ali-sample",
      name: "Ali",
      language: "Urdu",
      text: "یہ مستقبل کی آواز کی ٹیکنالوجی ہے",
      flag: "🇵🇰",
      voiceId: "ErXwobaYiN019PkySvjV",
    },
  ]

  const useCases = [
    { icon: Users, title: "YouTube", desc: "Engaging voiceovers" },
    { icon: BookOpen, title: "Podcast", desc: "Professional narration" },
    { icon: Video, title: "Audiobook", desc: "Immersive storytelling" },
    { icon: Presentation, title: "Drama Dubbing", desc: "Emotional performances" },
    { icon: Heart, title: "Accessibility", desc: "Support for all" },
    { icon: BookOpen, title: "Education", desc: "Learning content" },
  ]

  // Initialize Web Speech API
  useEffect(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      const loadVoices = () => {
        const voices = speechSynthesis.getVoices()
        setAvailableVoices(voices)

        console.log(
          "All available voices:",
          voices.map((v) => ({ name: v.name, lang: v.lang })),
        )

        // Categorize voices by language
        const englishVoices = voices
          .filter((voice) => voice.lang.startsWith("en"))
          .map((voice, index) => ({
            id: `web-speech-en-${index}`,
            name: `${voice.name}`,
            accent: voice.lang.includes("US") ? "American" : voice.lang.includes("GB") ? "British" : "English",
            gender:
              voice.name.toLowerCase().includes("female") || voice.name.toLowerCase().includes("woman")
                ? "Female"
                : "Male",
            voice: voice,
          }))

        // FLEXIBLE: Look for Urdu voices AND Hindi voices (which work great for Urdu)
        const urduVoices = voices
          .filter((voice) => {
            const lang = voice.lang.toLowerCase()
            const name = voice.name.toLowerCase()
            return (
              // Actual Urdu voices
              lang.startsWith("ur") ||
              lang === "ur-pk" ||
              lang === "ur-in" ||
              (name.includes("urdu") && !name.includes("hindi")) ||
              (name.includes("pakistan") && !name.includes("hindi")) ||
              // Hindi voices (work great for Urdu!)
              lang.startsWith("hi") ||
              lang === "hi-in" ||
              name.includes("hindi") ||
              name.includes("india")
            )
          })
          .map((voice, index) => ({
            id: `web-speech-ur-${index}`,
            name:
              voice.name.includes("hindi") || voice.lang.startsWith("hi")
                ? `${voice.name} (Hindi - Works for Urdu)`
                : `${voice.name}`,
            accent: voice.lang.includes("IN") ? "Indian" : voice.lang.includes("PK") ? "Pakistani" : "South Asian",
            gender:
              voice.name.toLowerCase().includes("female") || voice.name.toLowerCase().includes("woman")
                ? "Female"
                : "Male",
            voice: voice,
          }))

        console.log("Found Urdu-compatible voices (including Hindi):", urduVoices)

        // Check if we have Urdu-compatible voices (including Hindi)
        setHasUrduVoices(urduVoices.length > 0)

        // If no real Urdu voices, don't provide fallback - show installation message instead
        let finalUrduVoices = urduVoices
        if (urduVoices.length === 0) {
          // Don't use English voices as fallback - show empty list to force installation
          finalUrduVoices = [
            {
              id: "no-urdu-voice",
              name: "No Urdu voices installed - Click Help to install",
              accent: "Install Required",
              gender: "System",
              voice: null as any,
            },
          ]
        }

        setWebSpeechVoices({
          english: englishVoices.slice(0, 6),
          urdu: finalUrduVoices,
        })
      }

      // Load voices immediately
      loadVoices()

      // Also load when voices change (some browsers load them asynchronously)
      speechSynthesis.onvoiceschanged = loadVoices

      // Force reload after delays for browsers that load voices asynchronously
      setTimeout(loadVoices, 100)
      setTimeout(loadVoices, 500)
      setTimeout(loadVoices, 1000)

      return () => {
        speechSynthesis.onvoiceschanged = null
      }
    }
  }, [])

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [darkMode])

  useEffect(() => {
    const saved = localStorage.getItem("magical-voice-history")
    if (saved) {
      setRecentConversions(JSON.parse(saved))
    }
  }, [])

  useEffect(() => {
    if (autoDetect && text) {
      const hasUrdu = /[\u0600-\u06FF]/.test(text)
      setSelectedLanguage(hasUrdu ? "urdu" : "english")
    }
  }, [text, autoDetect])

  const saveToHistory = (text: string) => {
    const newHistory = [text.slice(0, 50) + (text.length > 50 ? "..." : ""), ...recentConversions.slice(0, 4)]
    setRecentConversions(newHistory)
    localStorage.setItem("magical-voice-history", JSON.stringify(newHistory))
  }

  // Real TTS using Web Speech API with proper Urdu handling
  const speakWithWebSpeech = (text: string, voiceId: string) => {
    return new Promise<void>((resolve, reject) => {
      if (!("speechSynthesis" in window)) {
        reject(new Error("Speech synthesis not supported"))
        return
      }

      // Stop any current speech
      speechSynthesis.cancel()

      // Small delay to ensure cancellation is processed
      setTimeout(() => {
        const utterance = new SpeechSynthesisUtterance(text)

        // Find the selected voice
        const currentVoices = webSpeechVoices[selectedLanguage as keyof typeof webSpeechVoices]
        const selectedVoiceObj = currentVoices.find((v) => v.id === voiceId)

        console.log("Selected voice object:", selectedVoiceObj)
        console.log("Available voices for", selectedLanguage, ":", currentVoices)

        if (selectedVoiceObj && selectedVoiceObj.voice) {
          utterance.voice = selectedVoiceObj.voice
          console.log("Using voice:", selectedVoiceObj.voice.name, selectedVoiceObj.voice.lang)
        } else {
          // More flexible fallback voice selection
          let fallbackVoice
          if (selectedLanguage === "urdu") {
            // First try actual Urdu voices
            fallbackVoice = availableVoices.find((v) => {
              const lang = v.lang.toLowerCase()
              const name = v.name.toLowerCase()
              return (
                lang.startsWith("ur") ||
                lang === "ur-pk" ||
                lang === "ur-in" ||
                name.includes("urdu") ||
                (name.includes("pakistan") && !name.includes("hindi"))
              )
            })

            // If no Urdu voice found, try Hindi voices (they work great for Urdu!)
            if (!fallbackVoice) {
              fallbackVoice = availableVoices.find((v) => {
                const lang = v.lang.toLowerCase()
                const name = v.name.toLowerCase()
                return lang.startsWith("hi") || lang === "hi-in" || name.includes("hindi") || name.includes("india")
              })

              if (fallbackVoice) {
                console.log("Using Hindi voice for Urdu text:", fallbackVoice.name)
                setApiError("Using Hindi voice for Urdu text - Hindi voices work great for Urdu pronunciation!")
              }
            }

            // Final fallback to any available voice
            if (!fallbackVoice) {
              fallbackVoice = availableVoices[0]
              if (fallbackVoice) {
                setApiError(
                  "Using default system voice for Urdu text. For better pronunciation, install Urdu or Hindi language pack.",
                )
              }
            }
          } else {
            fallbackVoice = availableVoices.find((v) => v.lang.startsWith("en")) || availableVoices[0]
          }

          if (fallbackVoice) {
            utterance.voice = fallbackVoice
            console.log("Using fallback voice:", fallbackVoice.name, fallbackVoice.lang)
          }
        }

        // Apply settings
        utterance.rate = Math.max(0.1, Math.min(10, speed[0]))
        utterance.pitch = Math.max(0, Math.min(2, pitch[0]))
        utterance.volume = 1

        // Set language - STRICT Urdu only
        // Set language - More flexible approach
        if (selectedLanguage === "urdu") {
          // Try Urdu language codes first
          const urduLangCodes = ["ur-PK", "ur-IN", "ur"]
          const hindiLangCodes = ["hi-IN", "hi"]
          let langSet = false

          // First try Urdu language codes
          for (const langCode of urduLangCodes) {
            try {
              utterance.lang = langCode
              langSet = true
              console.log("Set language to:", langCode)
              break
            } catch (e) {
              console.log("Failed to set language:", langCode)
              continue
            }
          }

          // If Urdu didn't work, try Hindi (works great for Urdu!)
          if (!langSet) {
            for (const langCode of hindiLangCodes) {
              try {
                utterance.lang = langCode
                langSet = true
                console.log("Set language to Hindi for Urdu text:", langCode)
                break
              } catch (e) {
                console.log("Failed to set Hindi language:", langCode)
                continue
              }
            }
          }

          // Final fallback to English
          if (!langSet) {
            utterance.lang = "en-US"
            console.log("Fallback to English for Urdu text")
          }
        } else {
          utterance.lang = "en-US"
        }

        setCurrentUtterance(utterance)

        utterance.onstart = () => {
          console.log("Speech started")
          setIsPlaying(true)
        }

        utterance.onend = () => {
          console.log("Speech ended")
          setIsPlaying(false)
          setCurrentUtterance(null)
          resolve()
        }

        utterance.onerror = (event) => {
          console.error("Speech error:", event.error, event)
          setIsPlaying(false)
          setCurrentUtterance(null)

          if (selectedLanguage === "urdu") {
            setApiError(
              "Urdu voice synthesis failed. Please install Urdu language pack or upgrade to ElevenLabs paid plan for proper Urdu voices.",
            )
          }

          reject(new Error(`Speech synthesis error: ${event.error}`))
        }

        console.log("Starting speech with:", {
          text: text.substring(0, 50) + "...",
          voice: utterance.voice?.name,
          lang: utterance.lang,
          rate: utterance.rate,
          pitch: utterance.pitch,
        })

        try {
          speechSynthesis.speak(utterance)
        } catch (error) {
          console.error("Error starting speech:", error)
          setIsPlaying(false)
          setCurrentUtterance(null)
          reject(error)
        }
      }, 100)
    })
  }

  // Online Urdu TTS using ResponsiveVoice API (free)
  const speakWithOnlineUrdu = (text: string) => {
    return new Promise<void>((resolve, reject) => {
      // Create a script tag to load ResponsiveVoice if not already loaded
      if (!window.responsiveVoice) {
        const script = document.createElement("script")
        script.src = "https://code.responsivevoice.org/responsivevoice.js?key=FREE"
        script.onload = () => {
          speakUrduText()
        }
        script.onerror = () => {
          reject(new Error("Failed to load online TTS service"))
        }
        document.head.appendChild(script)
      } else {
        speakUrduText()
      }

      function speakUrduText() {
        try {
          setIsPlaying(true)
          window.responsiveVoice.speak(text, "Hindi Female", {
            rate: speed[0],
            pitch: pitch[0],
            volume: 1,
            onstart: () => {
              console.log("Online Urdu TTS started")
              setIsPlaying(true)
            },
            onend: () => {
              console.log("Online Urdu TTS ended")
              setIsPlaying(false)
              resolve()
            },
            onerror: (error: any) => {
              console.error("Online TTS error:", error)
              setIsPlaying(false)
              reject(new Error("Online TTS failed"))
            },
          })
        } catch (error) {
          setIsPlaying(false)
          reject(error)
        }
      }
    })
  }

  // Multiple TTS Engine Support
  const speakWithMultipleTTS = async (text: string, engine = "auto") => {
    return new Promise<void>((resolve, reject) => {
      try {
        // Method 1: ResponsiveVoice (Free)
        if (engine === "responsive" || engine === "auto") {
          if (!window.responsiveVoice) {
            const script = document.createElement("script")
            script.src = "https://code.responsivevoice.org/responsivevoice.js?key=FREE"
            script.onload = () => speakWithResponsiveVoice()
            script.onerror = () => tryNextEngine()
            document.head.appendChild(script)
          } else {
            speakWithResponsiveVoice()
          }

          function speakWithResponsiveVoice() {
            window.responsiveVoice.speak(text, "Hindi Female", {
              rate: speed[0],
              pitch: pitch[0],
              volume: 1,
              onstart: () => setIsPlaying(true),
              onend: () => {
                setIsPlaying(false)
                resolve()
              },
              onerror: tryNextEngine,
            })
          }
        }

        // Method 2: Google Translate TTS (Backup)
        function tryNextEngine() {
          if (engine === "auto") {
            speakWithGoogleTTS()
          } else {
            reject(new Error("TTS engine failed"))
          }
        }

        function speakWithGoogleTTS() {
          const utterText = encodeURIComponent(text)
          const audioUrl = `https://translate.google.com/translate_tts?ie=UTF-8&tl=ur&client=tw-ob&q=${utterText}`

          const audio = new Audio(audioUrl)
          audio.crossOrigin = "anonymous"

          setCurrentAudio(audio)
          setIsPlaying(true)

          audio.play().catch(() => {
            // If Google TTS fails, try Web Speech API
            speakWithWebSpeech(text, selectedVoice).then(resolve).catch(reject)
          })

          audio.onended = () => {
            setIsPlaying(false)
            setCurrentAudio(null)
            resolve()
          }

          audio.onerror = () => {
            setIsPlaying(false)
            setCurrentAudio(null)
            // Final fallback to Web Speech API
            speakWithWebSpeech(text, selectedVoice).then(resolve).catch(reject)
          }
        }
      } catch (error) {
        reject(error)
      }
    })
  }

  const handlePlaySample = async (sample: (typeof sampleVoices)[0]) => {
    setIsLoading(true)
    setApiError(null)
    setDemoResult(null)

    try {
      // First try ElevenLabs API
      const result = await convertTextToSpeech(sample.text, sample.voiceId, {
        speed: 1,
        pitch: 1,
        emotion: "natural",
      })

      if (result.success && result.audioUrl) {
        const audio = new Audio(result.audioUrl)
        setCurrentAudio(audio)
        setIsPlaying(true)
        audio.play()
        audio.onended = () => {
          setIsPlaying(false)
          setCurrentAudio(null)
        }
      } else if (result.fallback) {
        // Switch to Web Speech API fallback
        setFallbackMode(true)

        // Check if it's Urdu and we don't have Urdu voices
        if (sample.language === "Urdu" && !hasUrduVoices) {
          setApiError("ElevenLabs API unavailable and no Urdu voices installed. Using English voice for Urdu text.")
        } else {
          setApiError("ElevenLabs API unavailable - Using browser's built-in voice synthesis")
        }

        try {
          await speakWithWebSpeech(sample.text, sample.voiceId)
          setDemoResult({
            success: true,
            message: `🎙️ Playing with browser TTS: "${sample.text.slice(0, 30)}${sample.text.length > 30 ? "..." : ""}"`,
            voiceInfo: { name: sample.name, gender: "Browser Voice" },
          })
        } catch (speechError) {
          console.error("Web Speech API error:", speechError)
          setApiError("Voice synthesis not available in this browser")
        }
      } else {
        setApiError(result.message || result.error)
      }
    } catch (error) {
      console.error("Error playing sample:", error)
      setApiError("Failed to play sample. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleConvert = async () => {
    if (!text.trim() || !selectedVoice) return

    // In handleConvert function, replace the Urdu voice check section with:
    if (selectedLanguage === "urdu" && !hasUrduVoices) {
      setApiError("No local Urdu voices found. Trying multiple online TTS services...")
      setFallbackMode(true)

      try {
        await speakWithMultipleTTS(text, "auto")
        setDemoResult({
          success: true,
          message: `🌐 Generated with online TTS: "${text.slice(0, 30)}${text.length > 30 ? "..." : ""}"`,
          voiceInfo: { name: "Multi-Engine Urdu Voice", gender: "Female" },
        })
      } catch (error) {
        setApiError("All TTS engines failed. Please try installing local Urdu voices or use a different browser.")
      }
      setIsLoading(false)
      return
    }

    setIsLoading(true)
    setApiError(null)
    setDemoResult(null)
    saveToHistory(text)

    try {
      // First try ElevenLabs API
      const result = await convertTextToSpeech(text, selectedVoice, {
        speed: speed[0],
        pitch: pitch[0],
        emotion: emotion,
      })

      if (result.success && result.audioUrl) {
        const audio = new Audio(result.audioUrl)
        setCurrentAudio(audio)
        setIsPlaying(true)
        audio.play()
        audio.onended = () => {
          setIsPlaying(false)
          setCurrentAudio(null)
        }
      } else if (result.fallback) {
        // Switch to Web Speech API fallback
        setFallbackMode(true)
        setApiError("ElevenLabs API unavailable - Using browser's built-in voice synthesis")

        try {
          await speakWithWebSpeech(text, selectedVoice)
          setDemoResult({
            success: true,
            message: `🎙️ Generated with browser TTS: "${text.slice(0, 30)}${text.length > 30 ? "..." : ""}"`,
            voiceInfo: { name: "Browser Voice", gender: "System Voice" },
          })
        } catch (speechError) {
          console.error("Web Speech API error:", speechError)
          setApiError("Voice synthesis not available in this browser")
        }
      } else {
        setApiError(result.message || result.error)
      }
    } catch (error) {
      console.error("Error converting text to speech:", error)
      setApiError("Failed to convert text to speech. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleDownload = async () => {
    if (!text.trim() || !selectedVoice) return

    setIsLoading(true)
    try {
      const result = await convertTextToSpeech(text, selectedVoice, {
        speed: speed[0],
        pitch: pitch[0],
        emotion: emotion,
      })

      if (result.success && result.audioUrl) {
        const a = document.createElement("a")
        a.href = result.audioUrl
        a.download = `magical-voice-${Date.now()}.mp3`
        a.click()
      } else if (result.fallback) {
        // For Web Speech API, we can't directly download, so create a report
        const demoData = await generateFallbackDemo(text, selectedVoice, {
          speed: speed[0],
          pitch: pitch[0],
          emotion: emotion,
        })

        const demoContent = `🎙️ MAGICAL VOICE - BROWSER TTS REPORT
═══════════════════════════════════════

📝 TEXT CONVERTED:
"${text}"

🎭 VOICE SETTINGS:
• Voice: Browser TTS (${selectedLanguage === "urdu" ? "Urdu 🇵🇰" : "English 🇬🇧"})
• Speed: ${speed[0]}x
• Pitch: ${pitch[0]}x
• Emotion: ${emotion}
• Urdu Voices Available: ${hasUrduVoices ? "Yes ✅" : "No ❌"}

📊 ANALYSIS:
• Text Length: ${text.length} characters
• Generated: ${new Date().toLocaleString()}
• Method: Web Speech API (Browser Built-in)

${
  !hasUrduVoices && selectedLanguage === "urdu"
    ? `
⚠️ URDU VOICE NOTICE:
No Urdu voices detected on your system. To get proper Urdu pronunciation:
1. Install Urdu language pack on your device
2. Or upgrade to ElevenLabs paid plan for AI Urdu voices

`
    : ""
}ℹ️ BROWSER TTS ACTIVE:
This text was spoken using your browser's built-in voice synthesis.
For high-quality AI voices, upgrade your ElevenLabs plan.

🌟 Thank you for trying Magical Voice!
`

        const blob = new Blob([demoContent], { type: "text/plain;charset=utf-8" })
        const url = URL.createObjectURL(blob)

        const a = document.createElement("a")
        a.href = url
        a.download = `magical-voice-browser-tts-${Date.now()}.txt`
        a.click()

        URL.revokeObjectURL(url)
        setApiError("Browser TTS report downloaded! For audio files, upgrade your ElevenLabs plan.")
      } else {
        setApiError(result.message || result.error)
      }
    } catch (error) {
      console.error("Error downloading:", error)
      setApiError("Failed to download. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleStop = () => {
    // Stop Web Speech API
    if (currentUtterance) {
      speechSynthesis.cancel()
      setCurrentUtterance(null)
      setIsPlaying(false)
    }

    // Stop regular audio
    if (currentAudio) {
      currentAudio.pause()
      currentAudio.currentTime = 0
      setCurrentAudio(null)
      setIsPlaying(false)
    }
  }

  const getErrorIcon = (error: string) => {
    if (error.includes("unusual activity") || error.includes("Free tier") || error.includes("disabled")) {
      return <AlertTriangle className="w-5 h-5 text-orange-400" />
    }
    if (error.includes("browser") || error.includes("Web Speech")) {
      return <Info className="w-5 h-5 text-blue-400" />
    }
    return <Info className="w-5 h-5 text-blue-400" />
  }

  const getErrorColor = (error: string) => {
    if (error.includes("unusual activity") || error.includes("Free tier") || error.includes("disabled")) {
      return "from-orange-500/10 to-red-500/10 border-orange-400/30"
    }
    if (error.includes("browser") || error.includes("Web Speech")) {
      return "from-blue-500/10 to-green-500/10 border-blue-400/30"
    }
    return "from-blue-500/10 to-purple-500/10 border-blue-400/30"
  }

  // Use Web Speech voices if available, otherwise fallback to static list
  const currentVoices =
    webSpeechVoices[selectedLanguage as keyof typeof webSpeechVoices].length > 0
      ? webSpeechVoices[selectedLanguage as keyof typeof webSpeechVoices]
      : voices[selectedLanguage as keyof typeof voices]

  return (
    <div
      className={`min-h-screen transition-all duration-700 ${
        darkMode
          ? "bg-gradient-to-br from-gray-900 via-purple-900 to-violet-900 text-white"
          : "bg-gradient-to-br from-purple-50 via-violet-50 to-indigo-100 text-gray-900"
      }`}
      style={{
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif",
      }}
    >
      <ParticleBackground />
      <UrduHelpModal isOpen={showUrduHelp} onClose={() => setShowUrduHelp(false)} />

      {/* Header */}
      <header className="relative z-10 p-6">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Mic className="w-8 h-8 text-violet-400 animate-pulse" />
              <div className="absolute -inset-1 bg-gradient-to-r from-violet-400 to-purple-600 rounded-full opacity-20 animate-ping" />
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-violet-400 to-purple-600 bg-clip-text text-transparent">
              Magical Voice
            </h1>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Switch
                checked={autoDetect}
                onCheckedChange={setAutoDetect}
                className="data-[state=checked]:bg-violet-500"
              />
              <Label className="text-sm">Auto Detect</Label>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setDarkMode(!darkMode)}
              className="rounded-full backdrop-blur-sm bg-white/10 border border-white/20 hover:bg-white/20 transition-all duration-300"
            >
              {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </Button>
          </div>
        </div>
      </header>

      {/* Urdu Voice Status */}
      {selectedLanguage === "urdu" && (
        <div className="relative z-10 px-6">
          <div className="max-w-7xl mx-auto">
            <div
              className={`backdrop-blur-sm bg-gradient-to-r ${hasUrduVoices ? "from-green-500/10 to-blue-500/10 border-green-400/30" : "from-orange-500/10 to-red-500/10 border-orange-400/30"} border rounded-xl p-4 mb-4`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  {hasUrduVoices ? (
                    <CheckCircle className="w-5 h-5 text-green-400" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-orange-400" />
                  )}
                  <div>
                    <h4 className="font-semibold text-sm">
                      {hasUrduVoices ? "🇵🇰 Urdu-Compatible Voices Available" : "🇵🇰 No Urdu/Hindi Voices Found"}
                    </h4>
                    <p className="text-xs opacity-75">
                      {hasUrduVoices
                        ? "Your system has Urdu or Hindi voices that can speak Urdu text perfectly"
                        : "Install Urdu or Hindi language pack - Hindi voices work great for Urdu!"}
                    </p>
                  </div>
                </div>
                {!hasUrduVoices && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowUrduHelp(true)}
                    className="text-orange-400 hover:text-orange-300"
                  >
                    <HelpCircle className="w-4 h-4 mr-1" />
                    Help
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* API Error Notification */}
      {apiError && (
        <div className="relative z-10 px-6">
          <div className="max-w-7xl mx-auto">
            <div className={`backdrop-blur-sm bg-gradient-to-r ${getErrorColor(apiError)} border rounded-xl p-4 mb-4`}>
              <div className="flex items-start space-x-3">
                {getErrorIcon(apiError)}
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">
                    {apiError.includes("browser") || apiError.includes("Web Speech")
                      ? "Browser TTS Active"
                      : apiError.includes("unusual activity") || apiError.includes("disabled")
                        ? "ElevenLabs Free Tier Disabled"
                        : "API Notice"}
                  </h4>
                  <p className="text-sm opacity-90">{apiError}</p>
                  {fallbackMode && (
                    <p className="text-xs mt-2 opacity-75">
                      🎙️ Using your browser's built-in voice synthesis for real speech
                    </p>
                  )}
                </div>
                <div className="flex space-x-2">
                  {apiError.includes("Urdu") && !hasUrduVoices && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowUrduHelp(true)}
                      className="text-orange-400 hover:text-orange-300"
                    >
                      <HelpCircle className="w-4 h-4" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setApiError(null)}
                    className="opacity-70 hover:opacity-100"
                  >
                    ×
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Demo Result Display */}
      {demoResult && (
        <div className="relative z-10 px-6">
          <div className="max-w-7xl mx-auto">
            <div className="backdrop-blur-sm bg-gradient-to-r from-green-500/10 to-blue-500/10 border border-green-400/30 rounded-xl p-4 mb-4">
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-400 mt-0.5" />
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Voice Generation Complete</h4>
                  <p className="text-sm opacity-90">{demoResult.message}</p>
                  <div className="text-xs mt-2 opacity-75 space-y-1">
                    <div>
                      🎙️ Voice: {demoResult.voiceInfo?.name} ({demoResult.voiceInfo?.gender})
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Fallback Mode Notification */}
      {fallbackMode && (
        <div className="relative z-10 px-6">
          <div className="max-w-7xl mx-auto">
            <div className="backdrop-blur-sm bg-gradient-to-r from-green-500/10 to-blue-500/10 border border-green-400/30 rounded-xl p-4 mb-4">
              <div className="flex items-center justify-center space-x-2 text-green-400">
                <Volume2 className="w-5 h-5" />
                <span className="text-sm font-medium">
                  🎙️ Browser TTS Active - Real voice synthesis using your system's built-in voices
                </span>
                <Volume2 className="w-5 h-5" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Hero Section */}
      <section className="relative z-10 py-20 px-6">
        <div className="max-w-5xl mx-auto text-center">
          <div className="mb-12 flex justify-center">
            <FloatingMic />
          </div>

          <h2 className="text-5xl md:text-7xl font-bold mb-8 bg-gradient-to-r from-violet-400 via-purple-500 to-indigo-600 bg-clip-text text-transparent leading-tight">
            Turn Your Words Into Magical Voice
          </h2>

          <p className={`text-xl md:text-2xl mb-12 ${darkMode ? "text-gray-300" : "text-gray-600"} max-w-3xl mx-auto`}>
            Hyper-realistic Urdu & English voices powered by Eleven Labs AI technology
          </p>

          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Button
              size="lg"
              className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white px-10 py-4 text-lg rounded-full shadow-2xl hover:shadow-violet-500/25 transition-all duration-300 transform hover:scale-105"
              onClick={() => document.getElementById("tts-engine")?.scrollIntoView({ behavior: "smooth" })}
            >
              <Play className="w-5 h-5 mr-2" />
              Start Converting
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="backdrop-blur-sm bg-white/10 border-white/30 hover:bg-white/20 px-10 py-4 text-lg rounded-full shadow-xl transition-all duration-300 transform hover:scale-105"
              onClick={() => document.getElementById("samples")?.scrollIntoView({ behavior: "smooth" })}
            >
              <Volume2 className="w-5 h-5 mr-2" />
              Try Sample Voice
            </Button>
          </div>
        </div>
      </section>

      {/* TTS Engine Panel */}
      <section id="tts-engine" className="relative z-10 py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <Card className="backdrop-blur-xl bg-white/10 border border-white/20 shadow-2xl rounded-3xl overflow-hidden relative">
            <div className="absolute inset-0 bg-gradient-to-r from-violet-500/5 to-purple-600/5 rounded-3xl" />
            <div className="absolute inset-0 border border-violet-300/20 rounded-3xl animate-pulse" />

            <CardContent className="p-8 relative z-10">
              <div className="grid lg:grid-cols-2 gap-10">
                {/* Left Column - Controls */}
                <div className="space-y-8">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <Label className="text-lg font-semibold mb-4 block flex items-center">
                        <span className="mr-2">Language</span>
                        {selectedLanguage === "urdu" ? "🇵🇰" : "🇬🇧"}
                        {selectedLanguage === "urdu" && !hasUrduVoices && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setShowUrduHelp(true)}
                            className="ml-2 text-orange-400 hover:text-orange-300 p-1"
                          >
                            <HelpCircle className="w-4 h-4" />
                          </Button>
                        )}
                      </Label>
                      <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                        <SelectTrigger className="backdrop-blur-sm bg-white/10 border-white/30 rounded-xl h-12 text-base">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="english">🇬🇧 English</SelectItem>
                          <SelectItem value="urdu">🇵🇰 Urdu {!hasUrduVoices && "(Install voices)"}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-lg font-semibold mb-4 block">Voice</Label>
                      <Select value={selectedVoice} onValueChange={setSelectedVoice}>
                        <SelectTrigger className="backdrop-blur-sm bg-white/10 border-white/30 rounded-xl h-12 text-base">
                          <SelectValue placeholder="Select a voice" />
                        </SelectTrigger>
                        <SelectContent>
                          {currentVoices.map((voice) => (
                            <SelectItem key={voice.id} value={voice.id}>
                              {voice.name} ({voice.gender})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <Switch
                      checked={showAdvanced}
                      onCheckedChange={setShowAdvanced}
                      className="data-[state=checked]:bg-violet-500"
                    />
                    <Label className="text-base font-medium">Advanced Settings</Label>
                    <Settings className="w-5 h-5 text-violet-400" />
                  </div>

                  {showAdvanced && (
                    <div className="space-y-6 p-6 rounded-2xl backdrop-blur-sm bg-white/5 border border-white/10">
                      <div>
                        <Label className="text-sm font-medium mb-3 block">Speed: {speed[0]}x</Label>
                        <Slider
                          value={speed}
                          onValueChange={setSpeed}
                          max={2}
                          min={0.5}
                          step={0.1}
                          className="w-full"
                        />
                      </div>

                      <div>
                        <Label className="text-sm font-medium mb-3 block">Pitch: {pitch[0]}x</Label>
                        <Slider
                          value={pitch}
                          onValueChange={setPitch}
                          max={2}
                          min={0.5}
                          step={0.1}
                          className="w-full"
                        />
                      </div>

                      <div>
                        <Label className="text-sm font-medium mb-3 block">Emotion</Label>
                        <Select value={emotion} onValueChange={setEmotion}>
                          <SelectTrigger className="backdrop-blur-sm bg-white/10 border-white/20">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="calm">😌 Calm</SelectItem>
                            <SelectItem value="natural">😊 Natural</SelectItem>
                            <SelectItem value="excited">🤩 Excited</SelectItem>
                            <SelectItem value="dramatic">🎭 Dramatic</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}
                </div>

                {/* Right Column - Text Input */}
                <div className="space-y-6">
                  <div>
                    <Label className="text-lg font-semibold mb-4 block">Your Text</Label>
                    <Textarea
                      placeholder={selectedLanguage === "urdu" ? "یہاں اپنا متن لکھیں..." : "Type your magic here..."}
                      value={text}
                      onChange={(e) => setText(e.target.value)}
                      className="min-h-[250px] backdrop-blur-sm bg-white/10 border-white/30 rounded-xl resize-none text-base p-4"
                      maxLength={1000}
                    />
                    <div className="flex justify-between items-center mt-3">
                      <span className="text-sm text-gray-400">{text.length}/1000 characters</span>
                      <div className="w-40 h-2 bg-gray-600/30 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-violet-400 to-purple-600 transition-all duration-300 rounded-full"
                          style={{ width: `${(text.length / 1000) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {(isPlaying || isLoading) && <WaveformAnimation isPlaying={isPlaying} />}

                  <div className="grid grid-cols-2 gap-4">
                    <Button
                      onClick={isPlaying ? handleStop : handleConvert}
                      disabled={((!text.trim() || !selectedVoice) && !isPlaying) || isLoading}
                      className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 rounded-xl h-12 text-base font-medium shadow-lg hover:shadow-violet-500/25 transition-all duration-300"
                    >
                      {isLoading ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : isPlaying ? (
                        <Pause className="w-4 h-4 mr-2" />
                      ) : (
                        <Play className="w-4 h-4 mr-2" />
                      )}
                      {isLoading ? "Processing..." : isPlaying ? "Stop" : fallbackMode ? "🎙️ Speak Text" : "Play Voice"}
                    </Button>

                    <Button
                      onClick={handleDownload}
                      disabled={!text.trim() || !selectedVoice || isLoading}
                      className="backdrop-blur-sm bg-white/10 border border-white/30 hover:bg-white/20 rounded-xl h-12 text-base font-medium transition-all duration-300"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      {fallbackMode ? "📄 Download Report" : "Download MP3"}
                    </Button>
                  </div>

                  <Button
                    onClick={() => setText("")}
                    variant="ghost"
                    className="w-full hover:bg-red-500/20 text-red-400 hover:text-red-300 rounded-xl h-12 transition-all duration-300"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Clear Text
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Voice Cloning Section */}
      <section className="relative z-10 py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <h3 className="text-4xl font-bold text-center mb-16 bg-gradient-to-r from-violet-400 to-purple-600 bg-clip-text text-transparent">
            🎭 Voice Cloning Lab
          </h3>

          <Card className="backdrop-blur-xl bg-white/10 border border-white/20 shadow-2xl rounded-3xl overflow-hidden relative">
            <div className="absolute inset-0 bg-gradient-to-r from-violet-500/5 to-purple-600/5 rounded-3xl" />

            <CardContent className="p-8 relative z-10">
              <div className="grid lg:grid-cols-2 gap-10">
                {/* Voice Upload */}
                <div className="space-y-6">
                  <h4 className="text-2xl font-bold mb-6">📤 Upload Urdu Voice Sample</h4>

                  <div className="border-2 border-dashed border-violet-400/30 rounded-xl p-8 text-center hover:border-violet-400/50 transition-all duration-300">
                    <div className="space-y-4">
                      <div className="w-16 h-16 mx-auto bg-gradient-to-r from-violet-500/20 to-purple-600/20 rounded-full flex items-center justify-center">
                        <Mic className="w-8 h-8 text-violet-400" />
                      </div>
                      <div>
                        <h5 className="font-semibold text-lg mb-2">Drop your Urdu audio file here</h5>
                        <p className="text-sm text-gray-400 mb-4">Upload a clear 30-60 second Urdu speech sample</p>
                        <p className="text-xs text-gray-500">Supported: MP3, WAV, M4A (Max 10MB)</p>
                      </div>
                      <Button className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 rounded-xl">
                        <Upload className="w-4 h-4 mr-2" />
                        Choose Audio File
                      </Button>
                    </div>
                  </div>

                  {/* Recording Option */}
                  <div className="p-6 rounded-xl backdrop-blur-sm bg-white/5 border border-white/10">
                    <h5 className="font-semibold mb-4 flex items-center">
                      <Mic className="w-5 h-5 mr-2 text-violet-400" />
                      Or Record Your Voice
                    </h5>
                    <div className="space-y-4">
                      <Button className="w-full bg-red-500 hover:bg-red-600 rounded-xl h-12" disabled={isLoading}>
                        {isLoading ? (
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                          <Mic className="w-4 h-4 mr-2" />
                        )}
                        {isLoading ? "Recording..." : "🎙️ Start Recording"}
                      </Button>
                      <p className="text-xs text-center text-gray-400">
                        Read this Urdu text clearly: "یہ میری آواز ہے اور میں اردو بول رہا ہوں"
                      </p>
                    </div>
                  </div>
                </div>

                {/* Voice Preview */}
                <div className="space-y-6">
                  <h4 className="text-2xl font-bold mb-6">🎧 Cloned Voice Preview</h4>

                  <div className="p-6 rounded-xl backdrop-blur-sm bg-white/5 border border-white/10">
                    <div className="text-center space-y-4">
                      <div className="w-20 h-20 mx-auto bg-gradient-to-r from-violet-500/20 to-purple-600/20 rounded-full flex items-center justify-center">
                        <Volume2 className="w-10 h-10 text-violet-400" />
                      </div>
                      <h5 className="font-semibold text-lg">Your Custom Urdu Voice</h5>
                      <p className="text-sm text-gray-400">
                        Upload an audio sample to create your personalized Urdu voice
                      </p>
                    </div>
                  </div>

                  {/* Pre-made Urdu Voices */}
                  <div className="space-y-4">
                    <h5 className="font-semibold">🇵🇰 Pre-trained Urdu Voices</h5>

                    {[
                      { name: "Fatima - Karachi Accent", desc: "Young female, clear pronunciation", flag: "🇵🇰" },
                      { name: "Ahmed - Lahore Accent", desc: "Male narrator, deep voice", flag: "🇵🇰" },
                      { name: "Ayesha - Islamabad Accent", desc: "Professional female voice", flag: "🇵🇰" },
                    ].map((voice, index) => (
                      <div
                        key={index}
                        className="p-4 rounded-xl backdrop-blur-sm bg-white/5 border border-white/10 hover:bg-white/10 transition-all duration-300"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <span className="text-2xl">{voice.flag}</span>
                            <div>
                              <h6 className="font-semibold text-sm">{voice.name}</h6>
                              <p className="text-xs text-gray-400">{voice.desc}</p>
                            </div>
                          </div>
                          <Button size="sm" variant="ghost" className="text-violet-400 hover:text-violet-300">
                            <Play className="w-3 h-3 mr-1" />
                            Preview
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Clone Voice Button */}
              <div className="mt-8 text-center">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 rounded-xl px-12 py-4 text-lg shadow-lg hover:shadow-violet-500/25 transition-all duration-300"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  ) : (
                    <Sparkles className="w-5 h-5 mr-2" />
                  )}
                  {isLoading ? "Cloning Voice..." : "🎭 Clone My Voice"}
                </Button>
                <p className="text-sm text-gray-400 mt-3">
                  Voice cloning takes 2-3 minutes. Your voice will be ready for text-to-speech conversion.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Sample Voices */}
      <section id="samples" className="relative z-10 py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-4xl font-bold text-center mb-16 bg-gradient-to-r from-violet-400 to-purple-600 bg-clip-text text-transparent">
            🎧 Sample Voices
          </h3>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {sampleVoices.map((sample) => (
              <Card
                key={sample.id}
                className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-2xl overflow-hidden hover:bg-white/15 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-violet-500/10"
              >
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-4">{sample.flag}</div>
                  <h4 className="font-bold text-xl mb-2">{sample.name}</h4>
                  <p className="text-sm text-violet-400 mb-3 font-medium">
                    {sample.language}
                    {sample.language === "Urdu" && !hasUrduVoices && (
                      <span className="text-orange-400 ml-1">(No Urdu voices)</span>
                    )}
                  </p>
                  <p className="text-sm mb-6 line-clamp-3 leading-relaxed">{sample.text}</p>
                  <Button
                    onClick={() => handlePlaySample(sample)}
                    disabled={isLoading}
                    size="sm"
                    className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 rounded-full px-6 py-2 shadow-lg hover:shadow-violet-500/25 transition-all duration-300"
                  >
                    {isLoading ? <Loader2 className="w-3 h-3 mr-1 animate-spin" /> : <Play className="w-3 h-3 mr-1" />}
                    {fallbackMode ? "🎙️ Speak Sample" : "Play Sample"}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Magical Voice */}
      <section className="relative z-10 py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-4xl font-bold text-center mb-16 bg-gradient-to-r from-violet-400 to-purple-600 bg-clip-text text-transparent">
            🚀 Why Magical Voice?
          </h3>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: "⚡", title: "Real-time AI speech generation", desc: "Instant voice synthesis" },
              { icon: "🎯", title: "Crystal-clear Urdu pronunciation", desc: "Perfect Pakistani accent" },
              { icon: "💾", title: "Downloadable high-quality MP3s", desc: "Professional audio files" },
              { icon: "🤖", title: "Eleven Labs engine integration", desc: "Industry-leading AI" },
              { icon: "🎭", title: "Emotion-based tone modulation", desc: "Express feelings naturally" },
              { icon: "👥", title: "Designed for creators & professionals", desc: "Built for your needs" },
            ].map((feature, index) => (
              <Card
                key={index}
                className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-2xl overflow-hidden hover:bg-white/15 transition-all duration-300 transform hover:scale-105"
              >
                <CardContent className="p-6">
                  <div className="text-3xl mb-4">{feature.icon}</div>
                  <h4 className="font-bold text-lg mb-2">{feature.title}</h4>
                  <p className="text-sm text-gray-400">{feature.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section className="relative z-10 py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-4xl font-bold text-center mb-16 bg-gradient-to-r from-violet-400 to-purple-600 bg-clip-text text-transparent">
            🎯 Perfect For
          </h3>

          <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-6">
            {useCases.map((useCase, index) => (
              <Card
                key={index}
                className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-2xl overflow-hidden hover:bg-white/15 transition-all duration-300 text-center transform hover:scale-105"
              >
                <CardContent className="p-6">
                  <useCase.icon className="w-10 h-10 mx-auto mb-4 text-violet-400" />
                  <h4 className="font-bold text-lg mb-2">{useCase.title}</h4>
                  <p className="text-sm text-gray-400">{useCase.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Recent Conversions */}
      {recentConversions.length > 0 && (
        <section className="relative z-10 py-16 px-6">
          <div className="max-w-5xl mx-auto">
            <h3 className="text-3xl font-bold mb-12 bg-gradient-to-r from-violet-400 to-purple-600 bg-clip-text text-transparent">
              📝 Recent Conversions
            </h3>

            <div className="space-y-4">
              {recentConversions.map((conversion, index) => (
                <Card
                  key={index}
                  className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-xl overflow-hidden hover:bg-white/15 transition-all duration-300"
                >
                  <CardContent className="p-4 flex items-center justify-between">
                    <span className="text-sm flex-1">{conversion}</span>
                    <Button size="sm" variant="ghost" className="ml-4">
                      <Play className="w-3 h-3" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Contact */}
      <section className="relative z-10 py-16 px-6">
        <div className="max-w-5xl mx-auto">
          <h3 className="text-4xl font-bold text-center mb-16 bg-gradient-to-r from-violet-400 to-purple-600 bg-clip-text text-transparent">
            💌 Get In Touch
          </h3>

          <Card className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-3xl overflow-hidden">
            <CardContent className="p-8">
              <div className="grid lg:grid-cols-2 gap-10">
                <div className="space-y-6">
                  <Input
                    placeholder="Your Name"
                    className="backdrop-blur-sm bg-white/10 border-white/30 rounded-xl h-12 text-base"
                  />
                  <Input
                    placeholder="Your Email"
                    type="email"
                    className="backdrop-blur-sm bg-white/10 border-white/30 rounded-xl h-12 text-base"
                  />
                  <Textarea
                    placeholder="Your Message"
                    className="min-h-[150px] backdrop-blur-sm bg-white/10 border-white/30 rounded-xl resize-none text-base"
                  />
                  <Button className="w-full bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 rounded-xl h-12 text-base font-medium shadow-lg hover:shadow-violet-500/25 transition-all duration-300">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Send Message
                  </Button>
                </div>

                <div className="space-y-8">
                  <div className="text-center">
                    <h4 className="text-2xl font-bold mb-8">Contact Information</h4>

                    <div className="space-y-6">
                      <div className="flex items-center justify-center space-x-4 p-4 rounded-xl backdrop-blur-sm bg-white/5 border border-white/10">
                        <Mail className="w-6 h-6 text-violet-400" />
                        <span className="text-base">support@magicalvoice.ai</span>
                      </div>

                      <div className="flex items-center justify-center space-x-4 p-4 rounded-xl backdrop-blur-sm bg-white/5 border border-white/10">
                        <Phone className="w-6 h-6 text-violet-400" />
                        <span className="text-base">+92 300 1234567</span>
                      </div>
                    </div>

                    <Button className="mt-8 bg-green-600 hover:bg-green-700 rounded-full px-8 py-3 text-base font-medium shadow-lg hover:shadow-green-500/25 transition-all duration-300">
                      <Phone className="w-4 h-4 mr-2" />
                      WhatsApp Support
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <section className="relative z-10 py-16 px-6 border-t border-white/10">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col lg:flex-row justify-between items-center mb-12">
            <div className="flex items-center space-x-4 mb-8 lg:mb-0">
              <div className="relative">
                <Mic className="w-10 h-10 text-violet-400 animate-pulse" />
                <div className="absolute -inset-2 bg-gradient-to-r from-violet-400 to-purple-600 rounded-full opacity-20 animate-ping" />
                <Sparkles className="w-5 h-5 text-yellow-400 absolute -top-1 -right-1 animate-pulse" />
              </div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-violet-400 to-purple-600 bg-clip-text text-transparent">
                Magical Voice
              </h1>
            </div>

            <div className="flex flex-wrap justify-center gap-8 text-base">
              <a href="#" className="hover:text-violet-400 transition-colors duration-300">
                Terms of Service
              </a>
              <a href="#" className="hover:text-violet-400 transition-colors duration-300">
                Privacy Policy
              </a>
              <a href="#" className="hover:text-violet-400 transition-colors duration-300">
                Support Center
              </a>
              <a href="#" className="hover:text-violet-400 transition-colors duration-300">
                FAQs
              </a>
            </div>
          </div>

          <div className="text-center">
            <p className="text-base text-gray-400 mb-4">
              © 2024 Magical Voice. All rights reserved. Powered by AI magic ✨
            </p>
            <p className="text-sm text-gray-500">
              Transform your words into magical voices with cutting-edge AI technology
            </p>
          </div>
        </div>
      </section>

      {/* Mobile Sticky Bottom Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-50 lg:hidden">
        <div className="backdrop-blur-xl bg-white/10 border-t border-white/20 p-4">
          <div className="flex space-x-2">
            <Button
              onClick={isPlaying ? handleStop : handleConvert}
              disabled={((!text.trim() || !selectedVoice) && !isPlaying) || isLoading}
              className="flex-1 bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 rounded-xl h-12"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : isPlaying ? (
                <Pause className="w-4 h-4 mr-2" />
              ) : (
                <Play className="w-4 h-4 mr-2" />
              )}
              {isLoading ? "Processing..." : isPlaying ? "Stop" : fallbackMode ? "🎙️ Speak" : "Play"}
            </Button>
            <Button
              onClick={handleDownload}
              disabled={!text.trim() || !selectedVoice || isLoading}
              variant="outline"
              className="backdrop-blur-sm bg-white/10 border-white/30 hover:bg-white/20 rounded-xl h-12 px-4"
            >
              <Download className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
